#!/bin/bash

# __INSTALLATION__

source setup-1-drive-layout.sh || touch stop_install

if [[ ! -f stop_install ]]; then
  source setup-2-pacstrap.sh
  source setup-3-post-pacstrap.sh
fi

#setup-4-inside-chroot.sh <- run from setup-3 automatically

./delay_step 6 "PC will reboot in 6 seconds"

# reboot
#setup-5-postreboot.sh
