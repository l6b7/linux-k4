#!/bin/bash

source config

sudo systemctl enable NetworkManager.service
sudo systemctl start NetworkManager.service

sudo chown -R $USER $HOME/linux-k4 ; echo "chown ${USER} -> ${HOME}/linux-k4"
sudo chgrp -R $USER $HOME/linux-k4 ; echo "chgrp ${USER} -> ${HOME}/linux-k4"
sleep 1

clear

rm -vf ~/.bash*
rm -Rvf ~/.config

sleep 1

mv  ~/linux-k4/resources/dotfiles/.static ~/.static
mv  ~/linux-k4/resources/dotfiles/.config ~/.config
mv  ~/linux-k4/resources/dotfiles/.librewolf ~/.librewolf
echo  "mv main-dir/config     -> .config"
echo  "mv main-dir/static     -> .static"
echo  "mv main-dir/.librewolf -> .librewolf"

mkdir ~/main-dir
mkdir ~/main-dir/media
mkdir ~/main-dir/downloads

ln -s ~/.config /home/l6b7/main-dir/.config
ln -s ~/.static /home/l6b7/main-dir/.static
ln -s ~/.local/share/Trash/files /home/l6b7/main-dir/.trash
ln -s /mnt /home/l6b7/main-dir/.mnt

sleep 1

sudo cp -v ~/.config/lf/lfrun /usr/bin/lfrun
sudo cp -v ~/.config/lf/lfroot /usr/bin/lfroot
ln -s ~/.config/zsh/zprofile /home/l6b7/.zprofile

sudo make -W  clean install -C /home/l6b7/.static/src/clipmenu -s
sudo make -W  clean install -C /home/l6b7/.static/src/dmenu -s
sudo make -W  clean install -C /home/l6b7/.static/src/dwm -s
sudo make -W  clean install -C /home/l6b7/.static/src/dwmblocks-async -s
sudo make -W  clean install -C /home/l6b7/.static/src/st -s

sleep 0.5

git clone https://aur.archlinux.org/yay.git

sleep 0.5

cd ~/yay && makepkg -sir --noconfirm PKGBUILD
rm -Rvf ~/yay

yay -S --noconfirm $(echo $YAY)


# more 
source setup-6-root-dir-files.sh

chsh -s $(which zsh)
