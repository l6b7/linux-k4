#!/bin/bash

lsblk

./delay_step 3 "fstab"

genfstab -U /mnt >> /mnt/etc/fstab
cat /mnt/etc/fstab

cp -r ../linux-k4 /mnt

lsblk

./delay_step 2 "Changing Root"

arch-chroot /mnt /bin/bash <<END
./linux-k4/setup-4-inside-chroot.sh
END

clear

lsblk

umount -Rl /mnt

sync

./delay_step 2 "Unmounting drives"
