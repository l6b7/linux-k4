#pragma once

#define CLICKABLE_BLOCKS  1     // Enable clickability for blocks
#define CMDLENGTH         45    // Trim block output to this length
#define DELIMITER         "  "  // Delimiter string used to separate blocks
#define LEADING_DELIMITER 0     // Whether a leading separator should be used
