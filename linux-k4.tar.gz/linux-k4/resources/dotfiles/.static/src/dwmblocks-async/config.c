#include "config.h"

#include "block.h"
#include "util.h"

Block blocks[] = {
 	  {"cat /tmp/recordingicon 2>/dev/null",	0,	9},
    {"sb-traffic",     3,    7},
    {"sb-memory",      5,    5},
    {"sb-disk",      600,    6},
    {"sb-battery",    30,    5},
    {"sb-bluetooth",  20,    4},
    {"sb-internet",   20,    3},
    {"sb-volume",      0,    1},
    {"sb-date",        1,    2},
};

const unsigned short blockCount = LEN(blocks);
