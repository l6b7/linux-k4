#pragma once

int setupX();
int closeX();
void setXRootName(char *);
