//dwm 6.2

#define TAGKEYS(KEY,TAG) \
{ MODKEY,                       KEY,      view,           {.ui = 1 << TAG} }, \
{ MODKEY|ControlMask,           KEY,      toggleview,     {.ui = 1 << TAG} }, \
{ MODKEY|ShiftMask,             KEY,      tag,            {.ui = 1 << TAG} }, \
{ MODKEY|ControlMask|ShiftMask, KEY,      toggletag,      {.ui = 1 << TAG} },
#define SHCMD(cmd) { .v = (const char*[]){ "/bin/sh", "-c", cmd, NULL } }

#define MODKEY Mod4Mask 
#define CTRL   ControlMask
#define SHIFT  ShiftMask
#define ALT    Mod1Mask

#define BRCKTL XK_bracketleft
#define BRCKTR XK_bracketright

#define TERMINAL "st"
#define BROWSER  "librewolf"
#define STATUSBAR "dwmblocks"

#include <X11/XF86keysym.h>

#include "exitdwm.c"
#include "grid.c"
#include "gaplessgrid.c"


/* bh->18 fontSize->10*/

static const char *fonts[]          = { "IosevkaNerdFont:size=9.4","noto-fonts-emoji:size=10"};
static const int user_bh = 11.4;
static const int scalepreview       = 4;

static const unsigned int borderpx  = 1;

static const unsigned int gappih    = 2;
static const unsigned int gappiv    = 2;
static const unsigned int gappoh    = 2;
static const unsigned int gappov    = 2;

static const char barBG[]        = "#000000";
static const char client[]       = "#000000";
static const char activeClient[] = "#ff00ff";
static const char floatClient[]  = "#4D003D";
/* static const char barText[]      = "#5F00FF"; */
static const char barText[]      = "#380099";


static const Rule rules[] = {
/*{class______, title______, float_,  x___, y___, z___, h___,   swallow, tags__, instnc, term__, mon___},*/
  {"st",        NULL,        0,        600,  300,  780,  420,   0,       0,      NULL,   1,      -1,   },
  {"st",        "spit",      0,        600,  300,  780,  420,   1,       0,      NULL,   0,      -1,   },
  {"st",        "ns",        1,        500,  250,  920,  580,   1,       0,      NULL,   1,      -1,   },
};


static const Layout layouts[] = {	{ " ˶ᵔ ᵕ ᵔ˶ ",   tile }, 	{ " ˶° ͜ʖ ͡°˶ ",   grid },	{ " ˶^•⩊•^˶ ",   gaplessgrid }, }; static const char *tags[] = { "1", "2", "3", "4", "5", "6", "7", "8", "9" }; static const float mfact     = 0.50; static const int nmaster     = 1; static const int resizehints = 1; static char dmenumon[2] = "0"; static const char *dmenucmd[] = { "dmenu_run", NULL }; static const unsigned int snap = 32; static const int topbar  = 1; static const int showbar = 1; static const int previewbar         = 0;        /* show the bar in the preview window */ static const int swallowfloating    = 0;        /* 1 means swallow floating windows by default */ static const int lockfullscreen = 0; /* 1 will force focus on the fullscreen window */ static const char black[]        = "#000000"; static const char *colors[][4]      = {[SchemeNorm] = { barText, barBG,  client,   black },[SchemeSel]  = { barText, barBG,  activeClient,  floatClient },}; static const int smartgaps          = 1;        /* 1 means no outer gap when there is only one window */



static Key keys[] = {
// launching
/* { MODKEY,            XK_0, quit,           {0} }, // zoom swap ? */
/* { ALT,               XK_space,  spawn,          {.v = (const char*[]){ TERMINAL,NULL } } }, */
{ ALT,	             XK_space, 	spawn,		      SHCMD("st -d $ZK_DIR_MAIN") },
{ MODKEY,            XK_space,  spawn,          {.v = (const char*[]){ BROWSER, NULL } } },
{ MODKEY,            XK_e,      spawn,          {.v = (const char*[]){ "lf_main-dir", NULL } } },
{ MODKEY|SHIFT,      XK_e,      spawn,          {.v = (const char*[]){ "lf_root", NULL } } },
{ MODKEY,            XK_m,      spawn,          {.v = (const char*[]){ "tauon", NULL } } },
/* { MODKEY|SHIFT,      XK_k,      spawn,          {.v = (const char*[]){ TERMINAL, "-t spit -e", "dwm_keycode_checker", NULL } } }, */
{ MODKEY,            XK_F8,     spawn,          {.v = (const char*[]){ "mon_select", NULL } } },
{ MODKEY|SHIFT,      XK_comma,  spawn,          {.v = (const char*[]){ "emoji_select", NULL } } },
{ MODKEY|SHIFT,      XK_period, spawn,          {.v = (const char*[]){ "sys_clipmenu", NULL } } },
{ 0,                 XK_Print,  spawn,          {.v = (const char*[]){ "screenshot", NULL } } },
{ SHIFT,             XK_Print,  spawn,          {.v = (const char*[]){ "record_screen", NULL } } },
{ MODKEY|SHIFT,      XK_p,      spawn,          {.v = (const char*[]){ "colorpicker_to_clipboard", NULL } } },
{ MODKEY|SHIFT,      XK_y,      spawn,          {.v = (const char*[]){ "ytfzf_dmenu", NULL } } },

// actions
{ MODKEY,            XK_q,      killclient,     {0} },
{ MODKEY,            XK_b,      togglebar,      {0} },
// system
{ MODKEY|SHIFT,      XK_Delete, spawn,          {.v = (const char*[]){"slock", NULL } } },
{ MODKEY|SHIFT,      XK_q,      exitdwm,        {0} },
// volume

{ MODKEY, XK_F1,		spawn,		SHCMD("changevolume mute; kill -35 $(pidof dwmblocks)") },
{ MODKEY, XK_F3,  	spawn,		SHCMD("changevolume up; kill -35 $(pidof dwmblocks)") },
{ MODKEY, XK_F2,  	spawn,		SHCMD("changevolume down; kill -35 $(pidof dwmblocks)") },

{ 0, XF86XK_AudioMute,	    	spawn,		SHCMD("changevolume mute; kill -35 $(pidof dwmblocks)") },
{ 0, XF86XK_AudioRaiseVolume,	spawn,		SHCMD("changevolume up; kill -35 $(pidof dwmblocks)") },
{ 0, XF86XK_AudioLowerVolume,	spawn,		SHCMD("changevolume down; kill -35 $(pidof dwmblocks)") },
//layouts
{ MODKEY,            XK_t,      setlayout,      {.v = &layouts[0]} },
{ MODKEY,            XK_g,      setlayout,      {.v = &layouts[1]} },
{ MODKEY|SHIFT,      XK_g,      setlayout,      {.v = &layouts[2]} },
{ MODKEY,            XK_f,      togglefullscreen,     {0} },

// window  actions
{ MODKEY,            XK_Return, zoom,           {0} }, // zoom swap ?
{ MODKEY|SHIFT,      XK_space,  togglefloating, {0} },
{ MODKEY|ShiftMask,  XK_b,      toggleborder,   {0} },
{ MODKEY|SHIFT,		   BRCKTL,	  spawn,	        SHCMD("transset-df -a --dec .0025") },
{ MODKEY|SHIFT,		   BRCKTR,	  spawn,	        SHCMD("transset-df -a --inc .0025") },
// master slave resize
{ MODKEY|SHIFT,      XK_Left,   setmfact,       {.f = -0.05} },
{ MODKEY|SHIFT,      XK_Right,  setmfact,       {.f = +0.05} },
// inc master size number
{ MODKEY|SHIFT,      XK_Up,    incnmaster,     {.i = +1 } },
{ MODKEY|SHIFT,      XK_Down,  incnmaster,     {.i = -1 } },

//Focusing Tags
{ MODKEY,            XK_Tab,   view,            {0} },
{ MODKEY,            BRCKTL,   viewprev,        {0} },
{ MODKEY,            BRCKTR,   viewnext,        {0} },
//Focusing Windows
{ MODKEY,            XK_Left,  focusdir,        {.i = 0 } }, // left
{ MODKEY,            XK_Right, focusdir,        {.i = 1 } }, // right
{ MODKEY,            XK_Up,    focusdir,        {.i = 2 } }, // up
{ MODKEY,            XK_Down,  focusdir,        {.i = 3 } }, // down
// Tags | 0 -> all tags
{ MODKEY,            XK_0,     view,            {.ui = ~0 } },
{ MODKEY|SHIFT,      XK_0,     tag,             {.ui = ~0 } },
TAGKEYS(             XK_1,                       0)
TAGKEYS(             XK_2,                       1)
TAGKEYS(             XK_3,                       2)
TAGKEYS(             XK_4,                       3)
TAGKEYS(             XK_5,                       4)
TAGKEYS(             XK_6,                       5)
TAGKEYS(             XK_7,                       6)
TAGKEYS(             XK_8,                       7)
TAGKEYS(             XK_9,                       8)
};



// Mouse Bindings 1left 2scroll 3right
static Button buttons[] = {
  /* click                event mask  button    function           argument */
// windows
	{ ClkClientWin,         MODKEY,     Button1,  moveorplace,       {.i = 1} },
	{ ClkClientWin,         MODKEY,     Button2,  togglefloating,    {0} },
// resizing floating windows
	{ ClkClientWin,         MODKEY,     Button3,  resizemouse,       {0} },
// tag bar
	{ ClkTagBar,            0,          Button1,  view,              {0} },
// clickable status bar
  { ClkStatusText,        0,          Button1,  sigstatusbar,      {.i = 1} },
  { ClkStatusText,        0,          Button2,  sigstatusbar,      {.i = 2} },
  { ClkStatusText,        0,          Button3,  sigstatusbar,      {.i = 3} },
  { ClkStatusText,        0,          Button4,  sigstatusbar,      {.i = 4} },
  { ClkStatusText,        0,          Button5,  sigstatusbar,      {.i = 5} },
  { ClkStatusText,        SHIFT,      Button1,  sigstatusbar,      {.i = 6} },
};

