require("l6b7.core")
require("l6b7.lazy")
require("l6b7.statusLine")
require("l6b7.keymaps")

vim.cmd.highlight('MsgArea guibg=#202328')
