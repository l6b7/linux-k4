return {'terrortylor/nvim-comment',
config = function()
local comment = require('nvim_comment').setup()
 end,
}
